package sn.thies.msd.parser

import org.json4s.DefaultFormats
import org.json4s.jackson.JsonMethods

import sn.thies.msd.reader.CsvReaderConfiguration
import sn.thies.msd.reader.JsonReaderConfiguration
import sn.thies.msd.reader.XmlReaderConfiguration
import sn.thies.msd.reader.ParquetReaderConfiguration
import sn.thies.msd.persister.CsvPersisterConfiguration
import sn.thies.msd.persister.JsonPersisterConfiguration
import sn.thies.msd.persister.XmlPersisterConfiguration
import sn.thies.msd.persister.ParquetPersisterConfiguration
object ConfigurationParser {
  implicit val format = DefaultFormats

  def getCsvReaderConfigurationFromJson(jsonString: String): CsvReaderConfiguration = {
    JsonMethods.parse(FileReaderUsingIOSource.getContent(jsonString)).extract[CsvReaderConfiguration]
  }

  def getJsonReaderConfigurationFromJson(jsonString: String): JsonReaderConfiguration = {
    JsonMethods.parse(FileReaderUsingIOSource.getContent(jsonString)).extract[JsonReaderConfiguration]
  }
  def getXmlReaderConfigurationFromJson(jsonString: String): XmlReaderConfiguration = {
    JsonMethods.parse(FileReaderUsingIOSource.getContent(jsonString)).extract[XmlReaderConfiguration]
  }
  def getParquetReaderConfigurationFromJson(jsonString: String): ParquetReaderConfiguration = {
    JsonMethods.parse(FileReaderUsingIOSource.getContent(jsonString)).extract[ParquetReaderConfiguration]
  }


  def getCsvPersisterConfigurationFromJson(jsonString: String): CsvPersisterConfiguration= {
    JsonMethods.parse(FileReaderUsingIOSource.getContent(jsonString)).extract[CsvPersisterConfiguration]
  }

  def getJsonPersisterConfigurationFromJson(jsonString: String): JsonPersisterConfiguration = {
    JsonMethods.parse(FileReaderUsingIOSource.getContent(jsonString)).extract[JsonPersisterConfiguration]
  }
  def getXmlPersisterConfigurationFromJson(jsonString: String): XmlPersisterConfiguration = {
    JsonMethods.parse(FileReaderUsingIOSource.getContent(jsonString)).extract[XmlPersisterConfiguration]
  }
  def getParquetPersisterConfigurationFromJson(jsonString: String): ParquetPersisterConfiguration = {
    JsonMethods.parse(FileReaderUsingIOSource.getContent(jsonString)).extract[ParquetPersisterConfiguration]
  }
}
