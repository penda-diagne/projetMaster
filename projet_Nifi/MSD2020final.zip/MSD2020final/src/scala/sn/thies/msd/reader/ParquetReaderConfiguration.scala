package sn.thies.msd.reader
import org.apache.spark.sql.{DataFrame, SparkSession}
case class ParquetReaderConfiguration(path: String)
  extends ReaderConfiguration {
  val format = "parquet"

  def read()(implicit spark2: SparkSession): DataFrame = {

    spark2.sqlContext.read.format(format)
      .load(path)

  }
}